<?php

error_reporting(E_ALL);

/**
 * unbenanntesModell - class.Stundenlohn.php
 *
 * $Id$
 *
 * This file is part of unbenanntesModell.
 *
 * Automatically generated on 20.08.2019, 12:32:17 with ArgoUML PHP module 
 * (last revised $Date: 2010-01-12 20:14:42 +0100 (Tue, 12 Jan 2010) $)
 *
 * @author firstname and lastname of author, <author@example.org>
 */

if (0 > version_compare(PHP_VERSION, '5')) {
    die('This file was generated for PHP 5');
}

/* user defined includes */
// section -64--88--78-22--dbaf7cb:16c8686fa2d:-8000:00000000000009BA-includes begin
// section -64--88--78-22--dbaf7cb:16c8686fa2d:-8000:00000000000009BA-includes end

/* user defined constants */
// section -64--88--78-22--dbaf7cb:16c8686fa2d:-8000:00000000000009BA-constants begin
// section -64--88--78-22--dbaf7cb:16c8686fa2d:-8000:00000000000009BA-constants end

/**
 * Short description of class Stundenlohn
 *
 * @access public
 * @author firstname and lastname of author, <author@example.org>
 */
class Stundenlohn
{
    // --- ASSOCIATIONS ---


    // --- ATTRIBUTES ---

    // --- OPERATIONS ---

} /* end of class Stundenlohn */

?>