<?php

interface StatisticsInterface {
	public function recalculate();
}

?>