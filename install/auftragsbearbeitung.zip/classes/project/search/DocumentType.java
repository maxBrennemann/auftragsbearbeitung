
public enum DocumentType {
    Customer, Product, Order
}
