<?php

error_reporting(E_ALL);

/**
 * unbenanntesModell - class.Lieferschein.php
 *
 * $Id$
 *
 * This file is part of unbenanntesModell.
 *
 * Automatically generated on 20.08.2019, 12:32:17 with ArgoUML PHP module 
 * (last revised $Date: 2010-01-12 20:14:42 +0100 (Tue, 12 Jan 2010) $)
 *
 * @author firstname and lastname of author, <author@example.org>
 */

if (0 > version_compare(PHP_VERSION, '5')) {
    die('This file was generated for PHP 5');
}

/**
 * include
 *
 * @author firstname and lastname of author, <author@example.org>
 */
require_once('class..php');

/**
 * include Formular
 *
 * @author firstname and lastname of author, <author@example.org>
 */
require_once('class.Formular.php');

/* user defined includes */
// section -64--88--78-22--dbaf7cb:16c8686fa2d:-8000:00000000000009C8-includes begin
// section -64--88--78-22--dbaf7cb:16c8686fa2d:-8000:00000000000009C8-includes end

/* user defined constants */
// section -64--88--78-22--dbaf7cb:16c8686fa2d:-8000:00000000000009C8-constants begin
// section -64--88--78-22--dbaf7cb:16c8686fa2d:-8000:00000000000009C8-constants end

/**
 * Short description of class Lieferschein
 *
 * @access public
 * @author firstname and lastname of author, <author@example.org>
 */
class Lieferschein
    /* multiple generalisations not supported by PHP: */
    /* extends ,
            Formular */
{
    // --- ASSOCIATIONS ---


    // --- ATTRIBUTES ---

    // --- OPERATIONS ---

    /**
     * Short description of method PDFgenerieren
     *
     * @access public
     * @author firstname and lastname of author, <author@example.org>
     * @return mixed
     */
    public function PDFgenerieren()
    {
        // section -64--88--78-22--dbaf7cb:16c8686fa2d:-8000:00000000000009D4 begin
        // section -64--88--78-22--dbaf7cb:16c8686fa2d:-8000:00000000000009D4 end
    }

} /* end of class Lieferschein */

?>