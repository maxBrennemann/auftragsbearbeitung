<h3>Seite nicht gefunden</h3>
<a href="<?=Link::getPageLink("")?>">Home</a>