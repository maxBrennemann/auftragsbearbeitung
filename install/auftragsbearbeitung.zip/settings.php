<?php

define('REWRITE_BASE', '/auftragsbearbeitung/');
define('WEB_URL', '/auftragsbearbeitung');
define('SUB_URL', '/content/');

/* database connection */
define('HOST', 'localhost');
define('USERNAME', 'root');
define('PASSWORD', '');
define('DATABASE', 'auftragsbearbeitung');

?>